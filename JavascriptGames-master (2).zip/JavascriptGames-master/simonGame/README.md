# Simon

This is a version of the memory game Simon, that I coded for one of my projects when i was learning how to code.  I added it to this repository for Hacktoberfest.

The game can also be accessed at [https://marissawood.github.io/project-1/](https://marissawood.github.io/project-1/) 

My original repository can also be viewed at [https://github.com/MarissaWood/project-1](https://github.com/MarissaWood/project-1)
